<?php  if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Display the Debug/Status page
 *
 * @author 		Patrick Rauland
 * @category 	Admin
 * @since     	2.2.50
 */

function ninja_forms_tab_system_status(){
	// Display the system status!
	include("system-status-html.php");
}