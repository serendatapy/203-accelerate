<?php

namespace Cloudinary\Api;

/**
 * Class AuthorizationRequired
 * @package Cloudinary\Api
 */
class AuthorizationRequired extends Error
{
}
